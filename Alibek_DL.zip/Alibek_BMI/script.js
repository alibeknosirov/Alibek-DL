// Global charts objects
let charts = {};

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts on dashboard page load
    setTimeout(() => {
        initializeCharts();
    }, 100);
});

// Page Navigation
function showPage(pageId) {
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));
    
    // Show selected page
    const selectedPage = document.getElementById(pageId);
    if (selectedPage) {
        selectedPage.classList.add('active');
    }
    
    // Update active nav item
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => item.classList.remove('active'));
    event.target.closest('.nav-item').classList.add('active');
    
    // Initialize charts if needed
    if (pageId === 'dashboard' && !charts.ragChart) {
        setTimeout(initializeCharts, 100);
    } else if (pageId === 'evm' && !charts.evmChart) {
        setTimeout(initializeEVMChart, 100);
    } else if (pageId === 'risk' && !charts.riskMatrix) {
        setTimeout(initializeRiskChart, 100);
    } else if (pageId === 'analytics' && !charts.comparisonChart) {
        setTimeout(initializeAnalyticsCharts, 100);
    } else if (pageId === 'gantt' && !charts.gantt) {
        setTimeout(initializeGanttChart, 100);
    }
}

// Initialize Dashboard Charts
function initializeCharts() {
    // RAG Status Donut Chart
    if (!charts.ragChart && document.getElementById('ragChart')) {
        const ragCtx = document.getElementById('ragChart').getContext('2d');
        charts.ragChart = new Chart(ragCtx, {
            type: 'doughnut',
            data: {
                labels: ['Yashil — Vaqtida (11)', 'Sariq — Kechikish (3)', 'Qizil — Muammo (1)'],
                datasets: [{
                    data: [11, 3, 1],
                    backgroundColor: ['#27ae60', '#f39c12', '#e74c3c'],
                    borderColor: '#ffffff',
                    borderWidth: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            font: { size: 12 },
                            padding: 15,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
    }
    
    // Success Indicators Line Chart
    if (!charts.successChart && document.getElementById('successChart')) {
        const successCtx = document.getElementById('successChart').getContext('2d');
        charts.successChart = new Chart(successCtx, {
            type: 'line',
            data: {
                labels: ['2019', '2020', '2021', '2022', '2023', '2024'],
                datasets: [
                    {
                        label: 'Loyihalar soni',
                        data: [38, 52, 68, 95, 156, 218],
                        borderColor: '#3498db',
                        backgroundColor: 'rgba(52, 152, 219, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Muvaffaqiyat %',
                        data: [41, 48, 55, 68, 76, 81],
                        borderColor: '#27ae60',
                        backgroundColor: 'rgba(39, 174, 96, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4,
                        yAxisID: 'y1',
                        borderDash: [5, 5]
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    legend: {
                        labels: { font: { size: 12 } }
                    }
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: { display: true, text: 'Loyihalar soni' }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: { display: true, text: 'Muvaffaqiyat %' },
                        grid: { drawOnChartArea: false }
                    }
                }
            }
        });
    }
}

// Initialize EVM Chart
function initializeEVMChart() {
    if (!charts.evmChart && document.getElementById('evmChart')) {
        const evmCtx = document.getElementById('evmChart').getContext('2d');
        charts.evmChart = new Chart(evmCtx, {
            type: 'line',
            data: {
                labels: ['1-oy', '2-oy', '3-oy', '4-oy', '5-oy', '6-oy', '7-oy', '8-oy'],
                datasets: [
                    {
                        label: 'PV — Rejalashtirilgan Qiymat',
                        data: [20, 50, 85, 120, 150, 190, 250, 300],
                        borderColor: '#2c3e50',
                        backgroundColor: 'rgba(44, 62, 80, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4
                    },
                    {
                        label: 'EV — Haqiqiy Bajarilgan Ish',
                        data: [18, 48, 82, 115, 143, 180, 240, 295],
                        borderColor: '#27ae60',
                        backgroundColor: 'rgba(39, 174, 96, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4
                    },
                    {
                        label: 'AC — Haqiqiy Xarajat',
                        data: [20, 52, 90, 130, 160, 200, 270, 320],
                        borderColor: '#e74c3c',
                        backgroundColor: 'rgba(231, 76, 60, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4,
                        borderDash: [5, 5]
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        labels: { font: { size: 12 } }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { callback: function(value) { return value + ' mln'; } }
                    }
                }
            }
        });
    }
}

// Initialize Risk Matrix Chart
function initializeRiskChart() {
    if (!charts.riskMatrix && document.getElementById('riskMatrixChart')) {
        const riskCtx = document.getElementById('riskMatrixChart').getContext('2d');
        charts.riskMatrix = new Chart(riskCtx, {
            type: 'bubble',
            data: {
                datasets: [
                    {
                        label: 'Xodimlar qarshiligi',
                        data: [{x: 0.55, y: 4.0, r: 12}],
                        backgroundColor: 'rgba(231, 76, 60, 0.7)',
                        borderColor: '#e74c3c',
                        borderWidth: 1
                    },
                    {
                        label: 'Talablar o\'zgarishi',
                        data: [{x: 0.60, y: 4.5, r: 12}],
                        backgroundColor: 'rgba(231, 76, 60, 0.7)',
                        borderColor: '#e74c3c',
                        borderWidth: 1
                    },
                    {
                        label: 'Texnik muammo',
                        data: [{x: 0.35, y: 3.5, r: 10}],
                        backgroundColor: 'rgba(243, 156, 18, 0.7)',
                        borderColor: '#f39c12',
                        borderWidth: 1
                    },
                    {
                        label: 'Kadrlar ketishi',
                        data: [{x: 0.40, y: 4.2, r: 10}],
                        backgroundColor: 'rgba(243, 156, 18, 0.7)',
                        borderColor: '#f39c12',
                        borderWidth: 1
                    },
                    {
                        label: 'Byudjet oshishi',
                        data: [{x: 0.25, y: 3.8, r: 8}],
                        backgroundColor: 'rgba(149, 165, 166, 0.7)',
                        borderColor: '#95a5a6',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        labels: { font: { size: 11 } }
                    }
                },
                scales: {
                    x: {
                        title: { display: true, text: 'Ehtimollik' },
                        min: 0,
                        max: 0.8
                    },
                    y: {
                        title: { display: true, text: 'Ta\'sir Darajasi' },
                        min: 0,
                        max: 5
                    }
                }
            }
        });
    }
}

// Initialize Analytics Charts
function initializeAnalyticsCharts() {
    // Comparison Chart
    if (!charts.comparisonChart && document.getElementById('comparisonChart')) {
        const compCtx = document.getElementById('comparisonChart').getContext('2d');
        charts.comparisonChart = new Chart(compCtx, {
            type: 'bar',
            data: {
                labels: [
                    'Vaqtida\nyakunlash (%)',
                    'Byudjet\nnormasida (%)',
                    'Muvaffaqiyat\n(%)',
                    'NPS\n(ball)',
                    'Qaror\n(soat)'
                ],
                datasets: [
                    {
                        label: 'Tizimdan Oldin',
                        data: [38, 44, 41, 59, 72],
                        backgroundColor: 'rgba(189, 195, 199, 0.7)',
                        borderColor: '#bdc3c7',
                        borderWidth: 1
                    },
                    {
                        label: 'Tizimdan Keyin',
                        data: [82, 85, 88, 91, 8],
                        backgroundColor: 'rgba(52, 152, 219, 0.7)',
                        borderColor: '#3498db',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        labels: { font: { size: 12 } }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }
    
    // NPV Chart
    if (!charts.npvChart && document.getElementById('npvChart')) {
        const npvCtx = document.getElementById('npvChart').getContext('2d');
        charts.npvChart = new Chart(npvCtx, {
            type: 'bar',
            data: {
                labels: ['0-yil', '1-yil', '2-yil', '3-yil', '4-yil', '5-yil'],
                datasets: [{
                    label: 'NPV (mln so\'m)',
                    data: [-477.7, -259.9, -44.7, 166.4, 372.3, 571],
                    backgroundColor: function(context) {
                        const value = context.dataset.data[context.dataIndex];
                        return value < 0 ? 'rgba(231, 76, 60, 0.7)' : 'rgba(39, 174, 96, 0.7)';
                    },
                    borderColor: function(context) {
                        const value = context.dataset.data[context.dataIndex];
                        return value < 0 ? '#e74c3c' : '#27ae60';
                    },
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                indexAxis: 'x',
                plugins: {
                    legend: {
                        labels: { font: { size: 12 } }
                    }
                },
                scales: {
                    y: {
                        ticks: {
                            callback: function(value) {
                                return value + ' mln';
                            }
                        }
                    }
                }
            }
        });
    }
}

// Initialize Gantt Chart
function initializeGanttChart() {
    if (!charts.gantt && document.getElementById('ganttChart')) {
        const ganttCtx = document.getElementById('ganttChart').getContext('2d');
        
        // Create a bar chart representation with horizontal bars
        charts.gantt = new Chart(ganttCtx, {
            type: 'bar',
            data: {
                labels: [
                    '1C ERP Joriy',
                    'CRM Tizim',
                    'HR Boshqaruv',
                    'Mobil Ilova',
                    'Blockchain To\'lov',
                    'IoT Monitoring',
                    'Data Warehouse'
                ],
                datasets: [
                    {
                        label: 'Progress (%)',
                        data: [65, 48, 78, 42, 22, 25, 88],
                        backgroundColor: [
                            '#27ae60', '#f39c12', '#27ae60',
                            '#27ae60', '#e74c3c', '#27ae60', '#3498db'
                        ],
                        borderColor: '#ffffff',
                        borderWidth: 2
                    }
                ]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: {
                        max: 100
                    }
                }
            }
        });
    }
}

// Create New Project
function createProject(event) {
    event.preventDefault();
    
    const form = event.target;
    const projectName = form.elements[0].value;
    const methodology = form.elements[1].value;
    
    if (projectName && methodology) {
        alert(`✓ Loyiha "${projectName}" muvaffaqiyatli portfelga qo'shildi!\n\nMetodologiya: ${methodology}`);
        form.reset();
        showPage('projects');
    }
}

// Utility: Format large numbers
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num;
}

// Utility: Get status color
function getStatusColor(spi) {
    if (spi >= 0.9) return 'green';
    if (spi >= 0.75) return 'orange';
    return 'red';
}

// Utility: Get status label
function getStatusLabel(spi) {
    if (spi >= 0.9) return 'Vaqtida';
    if (spi >= 0.75) return 'Kechikish';
    return 'Muammo';
}
