# ProJect-IT — IT Loyiha Boshqaruv Platformasi

**Versiya:** 1.0.0  
**Muallif:** Nosirov Alibek  
**Tashkilot:** InnoTech MChJ  
**Standart:** PMBOK 7 + Agile Metodologiyasi

---

## 📋 Loyiha Tavsifi

**ProJect-IT** — IT loyihalarini boshqarishning zamonaviy veb-platformasi. PMBOK 7 standartlari va Agile metodologiyasiga asoslangan. Loyihalar, muammolar va riskni boshqarishning to'liq echimi.

### ✨ Asosiy Xususiyatlar

✅ **PMO Dashboard (Bosh Panel)**
- RAG (Red-Amber-Green) statuslarining vizualizatsiyasi
- Loyihalar xotirasining dinamik statistikasi
- Haqiqiy vaqtda muammo va xavf ko'rsatkilari
- KPI kartalar va real-vaqt metrikalar

📊 **EVM Monitoring (Earned Value Management)**
- Bujetga nisbatan ishlanganlik tahlili
- Vaqt va bujet samaradorligining taqqoslashishi
- Prognozlashtirilgan tugash sanasi (EAC, ETC)

📅 **Gantt Jadvali**
- Loyihalarning vaqt jadvalini vizualizatsiyasi
- Ish jadvallashtirisining ruxsatlarini ko'rishish
- Asosan topshiriqlarning o'zaro bog'lanishlari

⚠️ **Risk & Hazara Boshqaruvi**
- Risk matritsasi (ehtimollik vs ta'sir)
- Risklar rejestri batafsil jadvali
- Kafilatsi choralari va reaksiya strategiyalari

📈 **Analitika va Investitsiya Tahlili**
- Loyihalar o'rtasida xilma-xillik taqlidi
- NPV, ROI, IRR ko'rsatkichlari
- 5-yillik tahlili prognozlar

🤖 **AI Bashorati (Yangi Loyihalar)**
- Muvaffaqiyat ehtimoli (Machine Learning)
- Vaqt va bujet xavf bashorati
- Optimal sprint strukturasi tavsiyalari

---

## 🚀 Ishga Tushirish

### Talablar
- **Brauzeri:** Chrome, Firefox, Safari, Edge (zamonaviy versiyalari)
- **Server:** Serverga ehtiyoj yo'q (Static HTML + JavaScript)
- **Internet:** Faqat Chart.js CDN uchun

### O'rnatish Qadamlari

#### 1️⃣ **En Oson Usul** - HTML Faylni Bevosita Oching
```bash
# index.html faylga 2 marta click qiling
# Yoki sog'dan: "Open with..." → Brauzer
```

#### 2️⃣ **Terminal orqali:**
```bash
git clone https://github.com/alibeknosirov/Alibek-BMI.git
cd Alibek-BMI
```

#### 3️⃣ **Local Server orqali** (tavsiya qilinadi):
```bash
# Python 3.x bilan
python -m http.server 8000

# Yoki Node.js bilan
npx http-server -p 8000

# Keyin brauzerna bunga oching:
# http://localhost:8000
```

---

## 📁 Loyiha Tuzilishi

```
Alibek-BMI/
├── index.html                 # Asosiy HTML sahifasi
├── styles.css                 # CSS uslublar va responsive dizayn
├── script.js                  # JavaScript interaktivlik
├── README.md                  # Qo'llanma (bu fayil)
└── docx_content/              # PMBOK dokumentatsiyasi
    ├── word/
    │   ├── document.xml       # Asosiy matn
    │   ├── media/             # Rasmlar (8 ta)
    │   ├── styles.xml
    │   └── theme/
    ├── docProps/
    │   ├── core.xml
    │   └── app.xml
    └── customXml/
```

---

## 🎨 Interfeys Bo'limlari

### 📊 **1. Bosh Panel (Dashboard)**
- **RAG Holati Diagrammasi:**
  - 🟢 Yashil (11 ta) — Vaqtida va buxetda
  - 🟡 Sariq (3 ta) — Kechikish riski bor
  - 🔴 Qizil (1 ta) — Jiddiy muammo (Blockchain To'lov)

- **Statistikalar:**
  - Jami Loyihalar: 15 ta
  - Portfel Qiymati: 1.24 mlrd so'm
  - Muvaffaqiyat: 81%

- **KPI Kartalar:**
  - Vaqtida: 73.3%
  - Byudjet Normasida: 85%
  - Qaror Vaqti: 8 soat

### 📋 **2. Loyihalar Portfeli**
Barcha loyihalar haqida to'liq jadval:
| Nomi | Metodologiya | Muddat | Byudjet | SPI | CPI | Holat |
|------|-------------|--------|---------|-----|-----|--------|
| CRM Tizimi | Scrum | 6 oy | 180M | 1.02 | 0.95 | 🟢 Vaqtida |
| Blockchain To'lov | Kanban | 9 oy | 320M | 0.84 | 0.72 | 🔴 Muammo |
| AI Chatbot | Scrumban | 4 oy | 120M | 1.05 | 1.00 | 🟢 Vaqtida |

### 📅 **3. Gantt Jadvali**
- 2025-yil bo'yicha loyihalar vaqt chizig'i
- Rangli statuslar va progress foizlari
- Ish topshiriqlarining ketma-ketligi

### 💰 **4. EVM Monitor (Earned Value Management)**
Qiymat Boshqaruvi Ko'rsatkichlari:
- **BAC** (Budget at Completion): 477.7 mln so'm
- **PV** (Planned Value): Rejalashtirish
- **EV** (Earned Value): Haqiqiy ishlanganlik
- **AC** (Actual Cost): Haqiqiy xarajatlar
- **SPI** (Schedule Performance): Vaqt samaradorligi
- **CPI** (Cost Performance): Bujet samaradorligi
- **EAC** (Estimate at Completion): Tekis tugash prognozi

### ⚠️ **5. Risk Register**
Risk Matritsasi (Bubble Chart):
- X o'qi: Ehtimollik (0-100%)
- Y o'qi: Ta'sir (0-100%)
- Bubble o'lchami: Risk prioriteti

**Top 5 Risklar:**
1. **Texnik muammolar** — Ehtimollik: 45%, Ta'sir: 90%
2. **Kadrlash muammolari** — Ehtimollik: 60%, Ta'sir: 70%
3. **Buxet axlati** — Ehtimollik: 35%, Ta'sir: 85%
4. **Vaqtli kechikish** — Ehtimollik: 50%, Ta'sir: 60%
5. **Stakeholder muvofiqlik** — Ehtimollik: 30%, Ta'sir: 50%

### 📈 **6. Analitika (Analytics)**
Taqlifi oldin/keyin:
| Ko'rsatkich | Oldin | Keyin | O'zgarish |
|-------------|-------|-------|-----------|
| Vaqtida Yakunlash | 38% | 82% | **+44 pp** ✓ |
| Byudjet Normasida | 44% | 85% | **+41 pp** ✓ |
| Muvaffaqiyat | 41% | 88% | **+47 pp** ✓ |
| Stakeholder NPS | 59 | 91 | **+32** ✓ |
| Qaror Vaqti | 72 h | 8 h | **-89%** ✓ |

### ➕ **7. Yangi Loyiha Yaratish**
AI-asosida bashorati bilan:
- **Form maydonlari:** Nomi, Metodologiya, Rahbari, Sanalar, Byudjet
- **ML Bashorata:** GradientBoost modeli orqali
  - Muvaffaqiyat ehtimoli: ~75%
  - Muddat xavfi: O'rta (35%)
  - Byudjet xavfi: Past (22%)
- **Tavsiyalar:** Optimal Sprint 5-7 kunlik

---

## 💻 Texnik Tafsilotlar

### Ishlatiladigan Texnologiyalar
```
Frontend Stack:
├── HTML5 — Semantik markup
├── CSS3 — Grid, Flexbox, Media Queries (Responsive)
├── JavaScript (Vanilla ES6+) — Interaktivlik
└── Chart.js 4.4.0 — Grafiklar va diagrammalar
```

### Diagramma Turlari
- **Doughnut Chart:** RAG Status
- **Line Chart:** Muvaffaqiyat statistikasi, EVM trend
- **Bar Chart:** Loyihalar taqqoslamasi, Analytics
- **Bubble Chart:** Risk Matritsasi

### Asosiy JavaScript Funksiyalari
```javascript
// Sahifalar o'rtasida o'tish
showPage('dashboard')
showPage('projects')
showPage('gantt')
showPage('evm')
showPage('risk')
showPage('analytics')
showPage('new-project')

// Diagrammalarni qayta-tuzish
initializeCharts()
initializeEVMChart()
initializeRiskChart()
initializeAnalyticsCharts()
```

### Muhim CSS Sinflar
```css
.header          /* Yuqori qism */
.sidebar         /* Chap navigatsiya */
.container       /* Asosiy konteyner */
.page            /* Sahifa bo'limlari */
.card            /* Ma'lumot kartalari */
.chart-container /* Grafik konteyner */
```

---

## 📱 Responsive Dizayn

Platform barcha cihozlarda ishlaydi:
| Cihozi | O'lchami | Layout | Sidebar |
|--------|---------|--------|---------|
| **Desktop** | 1200px+ | 2-3 ustun | Doimiy |
| **Tablet** | 768-1199px | 2 ustun | Yashiringan |
| **Mobil** | <768px | 1 ustun | Drawerda |

---

## 🎨 Ranglar Tema

| Element | Rang | Kod |
|---------|------|------|
| Yashil (Muvaffaqiyat) | 🟢 | #27ae60 |
| Sariq (Ogohlantirish) | 🟡 | #f39c12 |
| Qizil (Xavf) | 🔴 | #e74c3c |
| Ko'k (Ma'lumot) | 🔵 | #3498db |
| Dark (Fon) | ⬛ | #2c3e50 |

---

## 🔧 Kustomizatsiya

### Ma'lumotlarni O'zgartirish
`script.js` faylida quyidagi qismlarni tahrir qiling:

#### RAG Ma'lumotlari
```javascript
// Lines ~45
data: [11, 3, 1],  // [Yashil, Sariq, Qizil]
labels: ['Yashil — Vaqtida (11)', 'Sariq — Kechikish (3)', 'Qizil — Muammo (1)']
```

#### Yillar bo'ylab Statistika
```javascript
// Lines ~75
labels: ['2019', '2020', '2021', '2022', '2023', '2024'],
data: [38, 52, 68, 95, 156, 218]
```

#### Loyihalar Ro'yxati
```javascript
// Lines ~150 (Projects table)
const projects = [
    { name: 'CRM Tizimi', ... },
    { name: 'Blockchain To'lov', ... },
    // ...
]
```

### CSS Tema O'zgartirish
`styles.css` da:
```css
/* Asosiy Ranglar */
--primary: #2c3e50;
--success: #27ae60;
--warning: #f39c12;
--danger: #e74c3c;
--info: #3498db;
```

---

## 📚 Foydalanish Stsenarlari

### 🏢 **PMO Manager uchun:**
```
1. Dashboard-ga kirib KPI larni tez ko'rish
2. RAG statusdan muammolarga e'tibor berish
3. Risk Reestrdagi xavflarni tahlil qilish
4. Gantt jadvalida jadvallashtirilishni kuzatish
```

### 👨‍💼 **Loyiha Rahbari uchun:**
```
1. O'z loyihasining EVM metrikalarini tekshirish
2. Progress foizini real-vaqtda kuzatish
3. Vaqt va bujet sapasini taqqoslash
4. Risklar uchun kafilatsi choralarini belgilash
```

### 💼 **Investor uchun:**
```
1. Analitika sahifasida NPV, ROI, IRR ko'rish
2. Portfel qiymatini va reytingini kuzatish
3. Investitsiya samaradorligini tahlil qilish
4. Muvaffaqiyat ehtimolini bilish
```

---

## 🔐 Ma'lumot Xavfsizligi

✅ **Qo'llanmalar:**
- Barcha ma'lumot brauzer-da saqlangan (localStorage yo'q)
- Server-ga ulanish yo'q
- HTML5 based statik application
- Birlamchi encryption yo'q (shuning uchun only for demo)

⚠️ **Diqqat:**
Bu test platformasi, haqiqiy biznes uchun suv tashkil etish tafsiya etilmaydi.

---

## 🆘 Tez Ko'chma Muammolar

### ❓ Diagrammalar ko'rinmayotgan?
```
✓ Hal: Internetga ulanish tekshiring (Chart.js CDN uchun)
✓ Brauzer cache ni tozalash: Ctrl+Shift+Delete
```

### ❓ Navigatsiya ishlamilyapti?
```
✓ Hal: JavaScript yoniq ekanini tekshiring (F12 → Console)
✓ Brauzerni qaytadan yuklang (Ctrl+R)
```

### ❓ Responsive dizayn to'g'ri kelmaydi?
```
✓ Hal: F12 → Device Toolbar orqali mobil ko'rinish sinab ko'ring
✓ Brauzer window o'lchamini o'zgartiring
```

### ❓ Sahifa to'liq yuklanmayapti?
```
✓ Hal: CDN yoqilgan bo'lishini tekshiring
✓ Console errorlarini ko'rish: F12 → Console
```

---

## 📖 Qo'shimcha Resurslar

- 📘 [PMBOK 7 Standartlar](https://www.pmi.org/)
- 📗 [Agile Manifesto](https://agilemanifesto.org/)
- 📙 [Chart.js Dokumentatsiyasi](https://www.chartjs.org/)
- 📕 [HTML5 Spetsifikatsiyasi](https://html.spec.whatwg.org/)
- 🟣 [CSS3 Flex va Grid](https://developer.mozilla.org/en-US/docs/Web/CSS)

---

## 📊 Loyiha Statistikasi

```
┌─────────────────────────────────────┐
│     ProJect-IT Statistikasi         │
├─────────────────────────────────────┤
│ Loyihalar soni:           15 ta      │
│ Portfel Qiymati:     1.24 mlrd so'm  │
│ Vaqtida Yakunlash:        82%        │
│ Byudjet Normasida:        85%        │
│ Muvaffaqiyat:             88%        │
│ Stakeholder NPS:          91         │
│ Qaror Vaqti:              8 soat     │
│ Risklar Boshqarildi:      100%       │
└─────────────────────────────────────┘
```

---

## 🤝 Hissa Qo'shish

Bug topgan yoki taklif qilmoqchi bo'lsangiz:

1. **GitHub Issues** ochish
2. **Pull Request** jo'natish
3. **Feedback** berish

```bash
git clone https://github.com/alibeknosirov/Alibek-BMI.git
cd Alibek-BMI
# O'zgartirishlari qiling
git add .
git commit -m "Tavsifi bilan"
git push origin main
```

---

## 👨‍💻 Muallif Ma'lumotlari

**Nosirov Alibek**
- 🔗 GitHub: [@alibeknosirov](https://github.com/alibeknosirov)
- 📧 Email: alibek.nosirov@innotech.uz
- 🏢 Tashkilot: InnoTech MChJ
- 🎓 Universitet: Toshkent Davlat Iqtisodiyot Universiteti

---

## 📜 Litsenziya

**MIT License** — Ozod foydalanish va o'zgartirishga ruxsat beriladi.

```
MIT License

Copyright (c) 2025 Alibek Nosirov

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software...
```

---

## 🙏 Rahmat!

**ProJect-IT** platformasidan foydalanganiniz uchun tashakkur! 

Agar savollaringiz yoki takliflariingiz bo'lsa, muallif bilan bog'laning.

---

**Oxirgi tahrir:** 2026-06-09  
**Versiya:** 1.0.0  
**Status:** ✅ Faol Ishlanmoqda  
**Language:** 🇺🇿 Uzbek (Latin)

---

## 📞 Qo'llab-Quvvatlash

- 💬 **Savollar uchun:** GitHub Discussions
- 🐛 **Bug haqida:** GitHub Issues
- 💡 **Taklif uchun:** GitHub Discussions
- 📧 **Shaxsi xat:** alibek.nosirov@innotech.uz

---

## ✨ Xulosa

ProJect-IT — bu modern IT loyiha boshqaruvining to'liq echimi:
- ✅ PMBOK 7 va Agile metodologiyasi
- ✅ Real-vaqt KPI monitoring
- ✅ Riskni boshqarish
- ✅ Investitsiya tahlili
- ✅ AI bashorata
- ✅ Responsive Dizayn
- ✅ Open Source

**Happy Project Management! 🚀**
